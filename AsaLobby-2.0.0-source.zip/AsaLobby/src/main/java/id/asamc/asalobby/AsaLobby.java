package id.asamc.asalobby;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public final class AsaLobby extends JavaPlugin {

    private Set<String> lobbyWorlds = new HashSet<>();
    private LobbyItems items;
    private GameMenu menu;
    private VisibilityManager visibility;
    private LobbyScoreboard scoreboard;
    private BukkitTask task;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        items = new LobbyItems(this);
        visibility = new VisibilityManager(this);
        scoreboard = new LobbyScoreboard(this);
        getServer().getPluginManager().registerEvents(new LobbyListener(this), this);
        reloadAll();
        getLogger().info("AsaLobby " + getPluginMeta().getVersion() + " aktif.");
    }

    @Override
    public void onDisable() {
        if (task != null) task.cancel();
        scoreboard.clearAll();
        for (Player p : Bukkit.getOnlinePlayers()) {
            visibility.reset(p);
            items.remove(p);
        }
    }

    public void reloadAll() {
        reloadConfig();
        lobbyWorlds = new HashSet<>();
        for (String w : getConfig().getStringList("worlds")) lobbyWorlds.add(w.toLowerCase(Locale.ROOT));
        items.reload();
        menu = new GameMenu(this);
        scoreboard.clearAll();

        if (task != null) task.cancel();
        long interval = Math.max(5L, getConfig().getLong("scoreboard.update-ticks", 20L));
        task = Bukkit.getScheduler().runTaskTimer(this, () -> scoreboard.updateAll(), interval, interval);

        for (Player p : Bukkit.getOnlinePlayers()) applyState(p);
    }

    public boolean isLobbyWorld(World w) {
        return w != null && lobbyWorlds.contains(w.getName().toLowerCase(Locale.ROOT));
    }

    /** Sinkronkan item, visibility, dan scoreboard sesuai world pemain saat ini. */
    public void applyState(Player p) {
        if (!p.isOnline()) return;
        visibility.reset(p);
        if (isLobbyWorld(p.getWorld())) {
            items.give(p);
            scoreboard.show(p);
        } else {
            items.remove(p);
            scoreboard.hide(p);
        }
    }

    public LobbyItems items() { return items; }
    public GameMenu menu() { return menu; }
    public VisibilityManager visibility() { return visibility; }
    public LobbyScoreboard scoreboard() { return scoreboard; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadAll();
            sender.sendMessage(Text.c("&aAsaLobby config di-reload."));
            return true;
        }
        sender.sendMessage(Text.c("&eGunakan: /" + label + " reload"));
        return true;
    }
}
