package id.asamc.asalobby;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;

public final class GameMenu implements InventoryHolder {

    private record Game(String command, boolean console) {}

    private final AsaLobby plugin;
    private final Inventory inventory;
    private final Map<Integer, Game> games = new HashMap<>();

    public GameMenu(AsaLobby plugin) {
        this.plugin = plugin;
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("game-selector");
        int rows = Math.max(1, Math.min(6, s.getInt("rows", 6)));
        this.inventory = Bukkit.createInventory(this, rows * 9, Text.c(s.getString("title", "&eGame Selector")));

        String fillerName = s.getString("filler", "NONE");
        if (fillerName != null && !fillerName.equalsIgnoreCase("NONE")) {
            ItemStack filler = new ItemStack(LobbyItems.material(fillerName, Material.BLACK_STAINED_GLASS_PANE));
            ItemMeta meta = filler.getItemMeta();
            meta.displayName(Text.c(" "));
            filler.setItemMeta(meta);
            for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, filler);
        }

        ConfigurationSection gs = s.getConfigurationSection("games");
        if (gs == null) return;
        for (String id : gs.getKeys(false)) {
            ConfigurationSection g = gs.getConfigurationSection(id);
            if (g == null) continue;
            int slot = g.getInt("slot", 0);
            if (slot < 0 || slot >= inventory.getSize()) {
                plugin.getLogger().warning("Slot game '" + id + "' di luar GUI: " + slot);
                continue;
            }
            Material mat = Material.matchMaterial(g.getString("material", "STONE"));
            if (mat == null) {
                plugin.getLogger().warning("Material game '" + id + "' tidak valid.");
                mat = Material.STONE;
            }
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Text.c(g.getString("name", id)));
            meta.lore(Text.list(g.getStringList("lore")));
            item.setItemMeta(meta);
            inventory.setItem(slot, item);

            String cmd = g.getString("command", "");
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            games.put(slot, new Game(cmd, "console".equalsIgnoreCase(g.getString("run-as", "player"))));
        }
    }

    public void open(Player p) {
        p.openInventory(inventory);
    }

    public void handleClick(Player p, int slot) {
        Game g = games.get(slot);
        if (g == null || g.command().isBlank()) return;
        p.closeInventory();
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!p.isOnline()) return;
            if (g.console()) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), g.command().replace("%player%", p.getName()));
            } else {
                p.performCommand(g.command());
            }
        });
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
