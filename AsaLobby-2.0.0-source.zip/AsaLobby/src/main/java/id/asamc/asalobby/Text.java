package id.asamc.asalobby;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;

public final class Text {
    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private Text() {}

    public static Component c(String s) {
        if (s == null) s = "";
        return LEGACY.deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    public static Component raw(String s) {
        return LEGACY.deserialize(s == null ? "" : s);
    }

    public static List<Component> list(List<String> in) {
        List<Component> out = new ArrayList<>();
        for (String s : in) out.add(c(s));
        return out;
    }
}
