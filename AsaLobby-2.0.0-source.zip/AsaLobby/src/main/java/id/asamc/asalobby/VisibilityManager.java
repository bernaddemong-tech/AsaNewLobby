package id.asamc.asalobby;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class VisibilityManager {
    private final AsaLobby plugin;
    private final Set<UUID> hiding = new HashSet<>();

    public VisibilityManager(AsaLobby plugin) {
        this.plugin = plugin;
    }

    public boolean isVisible(Player p) {
        return !hiding.contains(p.getUniqueId());
    }

    /** visible = true: tampilkan player lain. false: sembunyikan player lain (hanya bagi p). */
    public void setVisible(Player p, boolean visible) {
        if (visible) {
            hiding.remove(p.getUniqueId());
            for (Player o : Bukkit.getOnlinePlayers()) if (o != p) p.showPlayer(plugin, o);
        } else {
            hiding.add(p.getUniqueId());
            for (Player o : Bukkit.getOnlinePlayers()) if (o != p) p.hidePlayer(plugin, o);
        }
    }

    /** Kembalikan ke mode terlihat. */
    public void reset(Player p) {
        if (hiding.contains(p.getUniqueId())) setVisible(p, true);
    }

    /** Pemain baru join: sembunyikan dari yang sedang mode Off. */
    public void onJoin(Player joined) {
        for (UUID id : hiding) {
            Player h = Bukkit.getPlayer(id);
            if (h != null && h != joined) h.hidePlayer(plugin, joined);
        }
    }

    public void onQuit(Player p) {
        hiding.remove(p.getUniqueId());
    }
}
