package id.asamc.asalobby;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class LobbyScoreboard {
    private static final int MAX_LINES = 15;

    private final AsaLobby plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public LobbyScoreboard(AsaLobby plugin) {
        this.plugin = plugin;
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("scoreboard.enabled", true);
    }

    public void show(Player p) {
        if (!enabled()) {
            hide(p);
            return;
        }
        Scoreboard sb = boards.get(p.getUniqueId());
        if (sb == null) {
            sb = create();
            boards.put(p.getUniqueId(), sb);
            p.setScoreboard(sb);
        }
        update(p, sb);
    }

    public void hide(Player p) {
        if (boards.remove(p.getUniqueId()) != null) {
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }

    public void forget(Player p) {
        boards.remove(p.getUniqueId());
    }

    public void clearAll() {
        for (UUID id : boards.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        boards.clear();
    }

    public void updateAll() {
        if (!enabled()) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.isLobbyWorld(p.getWorld())) show(p);
        }
    }

    private Scoreboard create() {
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = sb.registerNewObjective("asalobby", Criteria.DUMMY,
                Text.c(plugin.getConfig().getString("scoreboard.title", "&l&eLOBBY")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.numberFormat(NumberFormat.blank());

        int size = Math.min(MAX_LINES, plugin.getConfig().getStringList("scoreboard.lines").size());
        for (int i = 0; i < size; i++) {
            String entry = "\u00a7" + Integer.toHexString(i) + "\u00a7r";
            Team t = sb.registerNewTeam("l" + i);
            t.addEntry(entry);
            obj.getScore(entry).setScore(size - i);
        }
        return sb;
    }

    private void update(Player p, Scoreboard sb) {
        List<String> lines = plugin.getConfig().getStringList("scoreboard.lines");
        double tps = Math.min(20.0, Bukkit.getTPS()[0]);
        String color = tps >= 18 ? "&a" : tps >= 15 ? "&e" : "&c";
        String tpsText = color + String.format("%.1f", tps);
        String online = String.valueOf(Bukkit.getOnlinePlayers().size());

        int size = Math.min(MAX_LINES, lines.size());
        for (int i = 0; i < size; i++) {
            Team t = sb.getTeam("l" + i);
            if (t == null) continue;
            String line = lines.get(i)
                    .replace("%online%", online)
                    .replace("%tps%", tpsText)
                    .replace("%name%", p.getName());
            t.prefix(Text.c(line));
        }
    }
}
