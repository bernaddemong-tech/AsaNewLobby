package id.asamc.asalobby;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class LobbyListener implements Listener {
    private final AsaLobby plugin;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public LobbyListener(AsaLobby plugin) {
        this.plugin = plugin;
    }

    private LobbyItems items() { return plugin.items(); }

    private void syncNextTick(Player p) {
        Bukkit.getScheduler().runTask(plugin, () -> plugin.applyState(p));
    }

    // ---------- Lifecycle ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.visibility().onJoin(e.getPlayer());
        syncNextTick(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        plugin.visibility().onQuit(p);
        plugin.scoreboard().forget(p);
        cooldown.remove(p.getUniqueId());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        syncNextTick(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        syncNextTick(e.getPlayer());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(items()::isLobbyItem);
    }

    // ---------- Protection ----------

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (items().isLobbyItem(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (items().isLobbyItem(e.getItem().getItemStack())) {
            e.setCancelled(true);
            e.getItem().remove();
        }
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (items().isLobbyItem(e.getMainHandItem()) || items().isLobbyItem(e.getOffHandItem()))
            e.setCancelled(true);
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        Player p = e.getPlayer();
        if (items().isLobbyItem(p.getInventory().getItem(e.getHand()))) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;

        if (e.getView().getTopInventory().getHolder(false) instanceof GameMenu menu) {
            e.setCancelled(true);
            if (e.getClickedInventory() != null
                    && e.getClickedInventory().equals(e.getView().getTopInventory())) {
                menu.handleClick(p, e.getRawSlot());
            }
            return;
        }

        boolean touch = items().isLobbyItem(e.getCurrentItem()) || items().isLobbyItem(e.getCursor());
        if (!touch && e.getClick() == ClickType.NUMBER_KEY) {
            touch = items().isLobbyItem(p.getInventory().getItem(e.getHotbarButton()));
        }
        if (!touch && e.getClick() == ClickType.SWAP_OFFHAND) {
            touch = items().isLobbyItem(p.getInventory().getItemInOffHand());
        }
        if (touch) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder(false) instanceof GameMenu
                || items().isLobbyItem(e.getOldCursor())) {
            e.setCancelled(true);
        }
    }

    // ---------- Item usage ----------

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a == Action.PHYSICAL) return;

        ItemStack item = e.getItem();
        String type = items().typeOf(item);
        if (type == null) return;

        Player p = e.getPlayer();
        if (!plugin.isLobbyWorld(p.getWorld())) {
            items().remove(p);
            e.setCancelled(true);
            return;
        }

        boolean right = a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK;

        switch (type) {
            case LobbyItems.SELECTOR -> {
                e.setCancelled(true);
                if (right && ready(p)) plugin.menu().open(p);
            }
            case LobbyItems.VISIBILITY -> {
                e.setCancelled(true);
                if (!ready(p)) return;
                boolean nowVisible = !plugin.visibility().isVisible(p);
                plugin.visibility().setVisible(p, nowVisible);
                p.getInventory().setItemInMainHand(items().visibility(nowVisible));
                p.sendMessage(Text.c(plugin.getConfig().getString(
                        nowVisible ? "messages.visibility-on" : "messages.visibility-off", "")));
            }
            case LobbyItems.BOOK -> {
                // Klik kanan membuka buku secara bawaan. Klik kiri tidak melakukan apa-apa.
                if (!right) e.setCancelled(true);
            }
            default -> { }
        }
    }

    /** Anti-spam 250ms (Bedrock kadang mengirim klik ganda). */
    private boolean ready(Player p) {
        long now = System.currentTimeMillis();
        Long last = cooldown.get(p.getUniqueId());
        if (last != null && now - last < 250) return false;
        cooldown.put(p.getUniqueId(), now);
        return true;
    }
}
