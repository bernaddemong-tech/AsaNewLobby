package id.asamc.asalobby;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BookMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class LobbyItems {
    public static final String SELECTOR = "selector";
    public static final String VISIBILITY = "visibility";
    public static final String BOOK = "book";

    private final AsaLobby plugin;
    private final NamespacedKey key;

    public LobbyItems(AsaLobby plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "lobby_item");
    }

    public void reload() { /* item dibangun langsung dari config saat dibutuhkan */ }

    public static Material material(String name, Material fallback) {
        Material m = name == null ? null : Material.matchMaterial(name);
        return m == null ? fallback : m;
    }

    private ItemStack tag(ItemStack item, String type) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, type);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack simple(ConfigurationSection s, Material fallback, String type) {
        ItemStack item = new ItemStack(material(s.getString("material"), fallback));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Text.c(s.getString("name", "")));
        meta.lore(Text.list(s.getStringList("lore")));
        item.setItemMeta(meta);
        return tag(item, type);
    }

    public ItemStack selector() {
        return simple(plugin.getConfig().getConfigurationSection("items.game-selector"), Material.COMPASS, SELECTOR);
    }

    public ItemStack visibility(boolean on) {
        String path = "items.visibility." + (on ? "on" : "off");
        return simple(plugin.getConfig().getConfigurationSection(path),
                on ? Material.LIME_DYE : Material.GRAY_DYE, VISIBILITY);
    }

    public ItemStack book() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("items.updates-book");
        ItemStack item = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) item.getItemMeta();
        meta.title(Text.raw(s.getString("title", "Updates Page")));
        meta.author(Text.raw(s.getString("author", "AsaMC")));
        meta.displayName(Text.c(s.getString("name", "&6Updates Page")));
        for (String page : s.getStringList("pages")) {
            Component c = Text.raw(page);
            meta.addPages(c);
        }
        item.setItemMeta(meta);
        return tag(item, BOOK);
    }

    public String typeOf(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    public boolean isLobbyItem(ItemStack item) {
        return typeOf(item) != null;
    }

    public void remove(Player p) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getContents();
        boolean changed = false;
        for (int i = 0; i < contents.length; i++) {
            if (isLobbyItem(contents[i])) {
                contents[i] = null;
                changed = true;
            }
        }
        if (changed) inv.setContents(contents);
        if (isLobbyItem(p.getItemOnCursor())) p.setItemOnCursor(null);
    }

    public void give(Player p) {
        remove(p);
        PlayerInventory inv = p.getInventory();
        var cfg = plugin.getConfig();
        if (cfg.getBoolean("items.game-selector.enabled", true))
            inv.setItem(cfg.getInt("items.game-selector.slot", 0), selector());
        if (cfg.getBoolean("items.visibility.enabled", true))
            inv.setItem(cfg.getInt("items.visibility.slot", 1), visibility(true));
        if (cfg.getBoolean("items.updates-book.enabled", true))
            inv.setItem(cfg.getInt("items.updates-book.slot", 8), book());
    }
}
